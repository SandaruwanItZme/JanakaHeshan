// Update the footer year automatically.
const yearElement = document.getElementById("year");

if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
}

// Add a small welcome interaction to the hero button if it is present.
const exploreButton = document.querySelector(".hero .button-primary");

if (exploreButton) {
    exploreButton.addEventListener("click", function () {
        // The link's normal anchor behaviour is kept; this adds a console message for practice.
        console.log("Welcome to Janaka's digital space!");
    });
}
